

import 'dart:async';

import 'package:flutter/material.dart';

class OTPVerificationScreen extends StatefulWidget {
  const OTPVerificationScreen({super.key});

  @override
  _OTPVerificationScreenState createState() => _OTPVerificationScreenState();
}

class _OTPVerificationScreenState extends State<OTPVerificationScreen> {
  late Timer _timer;
  int _timeRemaining = 60;  
  bool _canResend = false;  

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    setState(() {
      _timeRemaining = 60;
      _canResend = false;
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_timeRemaining > 0) {
        setState(() {
          _timeRemaining--;
        });
      } else {
        setState(() {
          _canResend = true;
        });
        timer.cancel();
      }
    });
  }

  void _resendCode() {
    if (_canResend) {
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Code resent successfully!")),
      );
      _startTimer();
    }
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Forget Password'),
        centerTitle: true,
      ),
      
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const Text(
              'Send code to +20100......62',
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildOTPBox(),
                _buildOTPBox(),
                _buildOTPBox(),
                _buildOTPBox(),
              ],
            ),
            const SizedBox(height: 20),
            Text(
              _canResend
                  ? 'Resend code'
                  : 'Resend code in $_timeRemaining seconds',
              style: TextStyle(
                fontSize: 16,
                color: _canResend ? Colors.blue : Colors.grey,
              ),
            ),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: _canResend ? _resendCode : null,
              child: Text(
                'Resend Code',
                style: TextStyle(
                  color: _canResend ? Colors.blue : Colors.grey,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  decoration:
                      _canResend ? TextDecoration.underline : TextDecoration.none,
                ),
              ),
            ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      )),
                onPressed: () {
                 
                },
                child: const Text('Continue',
                
                style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold),),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildOTPBox() {
    return Container(
      width: 50,
      height: 50,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: const Center(
        child: TextField(
          textAlign: TextAlign.center,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(border: InputBorder.none),
        ),
      ),
    );
  }
}
