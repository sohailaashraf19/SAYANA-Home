import 'package:flutter/material.dart';

class ResetpassScreen extends StatelessWidget {
  const ResetpassScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: IconButton(
           icon: Image.asset('images/image.png', width: 50, height: 50,),

          onPressed: () {
            Navigator.pop(context);}), 

            title: Text
            (
              'Reset password',
              style: TextStyle(
                fontSize: 24,
              ),

            
            ),
            

        
            
            
        
      ),
      body:Column(
        children: [
          Text('Create a new password ')
        ],

      ) ,
    );
  }
}