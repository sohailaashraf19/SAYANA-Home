import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:my_house_design/auth/persentation/screens/forgtpass_screen.dart';
import 'package:my_house_design/auth/persentation/screens/signup_screen.dart';
import 'package:my_house_design/presentation/views/home_view.dart';
import 'package:my_house_design/presentation/views/seller_home_page.dart';

class SigninScreen extends StatefulWidget {
  const SigninScreen({super.key});

  @override
  State<SigninScreen> createState() => _SigninScreenState();
}

class _SigninScreenState extends State<SigninScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isRememberMe = false;
  bool _isObscure = true;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: const Color(0xFFFBFBFB),
        body: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 30.w),
            child: Column(
              children: [
                Image.asset('assets/images/SYANA HOME.png', width: 250, height: 250),
                SizedBox(height: 20.h),

                _buildInputField(
                  controller: _emailController,
                  hintText: 'Email',
                  icon: Icons.email,
                ),
                SizedBox(height: 15.h),
                _buildInputField(
                  controller: _passwordController,
                  hintText: 'Password',
                  icon: Icons.lock,
                  obscureText: _isObscure,
                  suffix: IconButton(
                    icon: Icon(_isObscure ? Icons.visibility_off : Icons.visibility, color: Colors.grey),
                    onPressed: () => setState(() => _isObscure = !_isObscure),
                  ),
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Checkbox(
                          value: _isRememberMe,
                          onChanged: (val) => setState(() => _isRememberMe = val!),
                          activeColor: Colors.black,
                        ),
                        Text('Remember me', style: TextStyle(fontSize: 14.sp)),
                      ],
                    ),
                    TextButton(
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ForgtpassScreen())),
                      child: Text('Forget Password?', style: TextStyle(fontSize: 14.sp, decoration: TextDecoration.underline)),
                    ),
                  ],
                ),
                SizedBox(height: 10.h),

                _buildSignInButton(),

                SizedBox(height: 40.h),
                _buildDivider(),
                SizedBox(height: 20.h),
                _buildSocialLogins(),
                SizedBox(height: 20.h),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Don’t have an account?", style: TextStyle(fontSize: 14.sp)),
                    TextButton(
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SignUpScreen())),
                      child: Text("Sign Up", style: TextStyle(fontSize: 16.sp)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
    bool obscureText = false,
    Widget? suffix,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30.r),
        border: Border.all(color: Colors.grey),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 6)],
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: TextField(
          controller: controller,
          obscureText: obscureText,
          decoration: InputDecoration(
            border: InputBorder.none,
            hintText: hintText,
            prefixIcon: Icon(icon, color: Colors.grey),
            suffixIcon: suffix,
          ),
        ),
      ),
    );
  }

  Widget _buildSignInButton() {
    return SizedBox(
      width: 250.w,
      height: 50.h,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30.r)),
        ),
        onPressed: _handleLogin,
        child: Text('Sign In', style: TextStyle(fontSize: 18.sp, color: Colors.white)),
      ),
    );
  }

  void _handleLogin() {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email == 'customer@gmail.com' && password == 'customer') {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeView()));
    } else if (email == 'BrightFuture@gmail.com' && password == '12345') {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const SellerHomePage()));
    } else {
      showDialog(
        context: context,
        builder: (_) => const AlertDialog(
          title: Text('Login Failed'),
          content: Text('Incorrect email or password. Please try again.'),
        ),
      );
    }
  }

  Widget _buildDivider() {
    return Row(
      children: [
        const Expanded(child: Divider(thickness: 1, color: Colors.black)),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 10.w),
          child: Text('or continue with', style: TextStyle(fontSize: 14.sp)),
        ),
        const Expanded(child: Divider(thickness: 1, color: Colors.black)),
      ],
    );
  }

  Widget _buildSocialLogins() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _socialIcon('assets/images/apple.png'),
        SizedBox(width: 20.w),
        _socialIcon('assets/images/facebook.png'),
        SizedBox(width: 20.w),
        _socialIcon('assets/images/google.png'),
      ],
    );
  }

  Widget _socialIcon(String path) {
    return GestureDetector(
      onTap: () {
        // TODO: Add functionality
      },
      child: Image.asset(path, height: 40.h),
    );
  }
}
