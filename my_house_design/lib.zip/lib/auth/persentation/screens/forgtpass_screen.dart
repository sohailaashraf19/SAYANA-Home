import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:my_house_design/auth/persentation/screens/otp_verification_screen.dart';

class ForgtpassScreen extends StatelessWidget {
  const ForgtpassScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFECE9E5),
      appBar: AppBar(
        title: Center(
          child: Text(
            "Forget password",
            style: TextStyle(fontSize: 20.sp),
          ),
        ),
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Image.asset('images/image.png', width: 50.w, height: 50.h),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 30.h),
              Text(
                "We will send a verification code\n to you to reset your password",
                style: TextStyle(fontSize: 15.sp,fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20.h),
              
              // Phone Number Field
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 40.h), 
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50.r),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      blurRadius: 5.r,
                      spreadRadius: 2,
                    )
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Phone Number", style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold)),
                    SizedBox(height: 10.h),
                    Row(
                      children: [
                        Icon(Icons.message, size: 24.sp, color: Colors.grey),
                        SizedBox(width: 10.w),
                        Expanded(
                          child: TextField(
                            keyboardType: TextInputType.phone,
                            decoration: const InputDecoration(
                              hintText: "+201...............",
                              border: InputBorder.none,
                            ),
                            style: TextStyle(fontSize: 16.sp),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              SizedBox(height: 20.h),

              // Email Field
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 40.h),  
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50.r),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      blurRadius: 5.r,
                      spreadRadius: 2,
                    )
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Email", style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold)),
                    SizedBox(height: 10.h),
                    Row(
                      children: [
                        Icon(Icons.email, size: 24.sp, color: Colors.grey),
                        SizedBox(width: 10.w),
                        Expanded(
                          child: TextField(
                            keyboardType: TextInputType.emailAddress,
                            decoration: const InputDecoration(
                              hintText: "cr...............@gmail.com",
                              border: InputBorder.none,
                            ),
                            style: TextStyle(fontSize: 16.sp, color: Colors.grey),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              SizedBox(height: 70.h), 
              // Continue Button
              SizedBox(
                width: double.infinity,
                height: 60.h,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.r),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>   OTPVerificationScreen ()),
                    );
                  },
                  child: Text(
                    "Continue",
                    style: TextStyle(fontSize: 18.sp, color: Colors.white),
                  ),
                ),
              ),
              
              SizedBox(height: 20.h), 
            ],
          ),
        ),
      ),
    );
  }
}
