import 'package:flutter/material.dart';
import 'signin_screen.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
       
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      backgroundColor: const Color(0xFFECE9E5),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: screenSize.width * 0.05,
            vertical: screenSize.height * 0.05,
          ),
          child: Column(
            children: [
              const Text(
                "Log In",
                style: TextStyle(fontSize: 24, color: Colors.black, fontFamily: 'Arial'),
              ),
              const SizedBox(height: 40),
              const Text(
                "Design your dream\nspace, one piece at\na time.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black, fontFamily: 'Arial'),
              ),
             const SizedBox(height: 30),

// Facebook
Container(
  width: double.infinity,
  padding: const EdgeInsets.symmetric(vertical: 15),
  decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(10),
    border: Border.all(color: Colors.grey.shade300),
  ),
  child: Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Image.asset("images/facebook.png", width: 25),
      const SizedBox(width: 10),
      const Text("Continue with Facebook", style: TextStyle(fontSize: 16)),
    ],
  ),
),

const SizedBox(height: 10),

// Google
Container(
  width: double.infinity,
  padding: const EdgeInsets.symmetric(vertical: 15),
  decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(10),
    border: Border.all(color: Colors.grey.shade300),
  ),
  child: Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Image.asset("images/google.png", width: 25),
      const SizedBox(width: 10),
      const Text("Continue with Google", style: TextStyle(fontSize: 16)),
    ],
  ),
),

const SizedBox(height: 10),

// Apple
Container(
  width: double.infinity,
  padding: const EdgeInsets.symmetric(vertical: 15),
  decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(10),
    border: Border.all(color: Colors.grey.shade300),
  ),
  child: Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Image.asset("images/apple.png", width: 25),
      const SizedBox(width: 10),
      const Text("Continue with Apple", style: TextStyle(fontSize: 16)),
    ],
  ),
),

const SizedBox(height: 20),

              Row(
                children: const [
                  Expanded(child: Divider(color: Colors.black)),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 30),
                    child: Text("or", style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold)),
                  ),
                  Expanded(child: Divider(color: Colors.black)),
                ],
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                ),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const SigninScreen()));
                },
                child: const Text("Sign with Password", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text("Don't have an account?", style: TextStyle(fontSize: 20, color: Colors.black)),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const SigninScreen()));
                    },
                    child: const Text("Sign Up",
                        style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    
    );
  }
}
  

  