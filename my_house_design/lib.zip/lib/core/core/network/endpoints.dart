class ApiConstants {
  static const String baseUrl = "https://olivedrab-llama-457480.hostingersite.com/public/api";

  static const String sellerLogin = "$baseUrl/seller/login";

  static const baseUrl1 = "https://olivedrab-llama-457480.hostingersite.com/public/api";

  static const sellerRegister = "$baseUrl1/seller/register";

   static const baseUrl0 = "https://olivedrab-llama-457480.hostingersite.com/public/api";
     static const String sellerLogout ="$url/seller/logout";

  static const String baseUrl2= "https://olivedrab-llama-457480.hostingersite.com/public/api";

  static const String buyerLogin ="$baseUrl2/buyer/login";

  static const String baseUrl3= "https://olivedrab-llama-457480.hostingersite.com/public/api";

  static const String buyerRegister ="$baseUrl/buyer/register";

  static const String url= "https://olivedrab-llama-457480.hostingersite.com/public/api";
  static const String buyerLogout ="$url/buyer/logout";

  static const String url1= "https://olivedrab-llama-457480.hostingersite.com/public/api";

  static const String buyerforgpass="$url1/forgot-password";




}
