import 'package:flutter/material.dart';
import 'package:my_house_design/feature/feature/buyer/presentation/screens/LogoutPageBuyer.dart';
import 'profile.dart';
import 'package:my_house_design/presentation/views/seller_home_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingssPage extends StatelessWidget {
  const SettingssPage({super.key});

  // Method to fetch the logged-in user's name
  Future<String> getUserName() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('userName') ?? 'Guest'; // Default to 'Guest' if not found
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF003664),
      appBar: AppBar(
        backgroundColor: const Color(0xFF003664),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text("Settings"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SellerHomePage(), // Replace with your home page widget
                            ),
                          );          },
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          FutureBuilder<String>(
            future: getUserName(), 
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return const Text('Error loading name', style: TextStyle(color: Colors.white));
              } else if (snapshot.hasData) {
                return _buildItem(context, snapshot.data!, Icons.person, () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) =>  ProfilePage()));
                });
              } else {
                return const Text('No data available', style: TextStyle(color: Colors.white));
              }
            },
          ),
          const SizedBox(height: 20),
          _buildItem(context, "Home", Icons.home, () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => const SellerHomePage()));
          }),
          SizedBox(height: 20,),
          _buildItem(context, "Offers", Icons.local_offer, () {}),
          SizedBox(height: 20,),
          _buildItem(context, "Feedback", Icons.feedback, () {}),
          SizedBox(height: 20,),
          _buildItem(context, "Help", Icons.help, () {}),
          SizedBox(height: 350,),
          const Divider(color: Colors.white54),
          _buildItem(context, "Logout", Icons.logout, () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => const LogoutPage()));
          }),
        ],
      ),
    );
  }

  Widget _buildItem(BuildContext context, String title, IconData icon, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: Colors.white),
      title: Text(title, style: const TextStyle(color: Colors.white)),
      onTap: onTap,
    );
  }
}
