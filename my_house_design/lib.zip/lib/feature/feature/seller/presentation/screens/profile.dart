import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/SellerProfileCubit.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/SellerProfileState.dart';
import 'package:my_house_design/presentation/views/seller_home_page.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile', style: TextStyle(color: Colors.white)),
        backgroundColor: Color(0xFF003664),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => SellerHomePage()),
            );
          },
        ),
      ),
      body: BlocProvider(
        create: (context) => SellerProfileCubit()..fetchProfile(),
        child: BlocBuilder<SellerProfileCubit, SellerProfileState>(
          builder: (context, state) {
            if (state is SellerProfileLoading) {
              return Center(child: CircularProgressIndicator());
            } else if (state is SellerProfileSuccess) {
              final profile = state.profileData;
nameController.text = profile['brand_name'] ?? '';
              emailController.text = profile['email'] ?? '';
              phoneController.text = profile['phone'] ?? '';

              return Padding(
                padding: const EdgeInsets.all(16.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 50,
                        backgroundImage: AssetImage('assets/images/4537028.png'),
                      ),
                      SizedBox(height: 20),
                      _buildInputField(Icons.person, 'Brand Name', nameController),
                      _buildInputField(Icons.email, 'Email', emailController),
                      _buildInputField(Icons.phone, 'Phone', phoneController),
                    ],
                  ),
                ),
              );
            } else if (state is SellerProfileFailure) {
              return Center(child: Text("❌ ${state.error}"));
            } else {
              return Center(child: Text("No profile data"));
            }
          },
        ),
      ),
    );
  }

  Widget _buildInputField(IconData icon, String label, TextEditingController controller) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Icon(icon, color: Color(0xFF003664)),
            SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: controller,
                decoration: InputDecoration(
                  labelText: label,
                  border: InputBorder.none,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
