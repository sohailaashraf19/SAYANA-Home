import 'package:flutter/material.dart';
import 'package:my_house_design/presentation/widgets/color.dart';
import 'package:my_house_design/feature/feature/seller/presentation/screens/seller_orders_page.dart';

class OrderInfoPage extends StatefulWidget {
  final Map<String, dynamic> order;

  const OrderInfoPage({super.key, required this.order});

  @override
  _OrderInfoPageState createState() => _OrderInfoPageState();
}

class _OrderInfoPageState extends State<OrderInfoPage> {
  String selectedStatus = 'pending';

  @override
  void initState() {
    super.initState();
    selectedStatus = widget.order['payment_status'];
  }

  Future<void> updateOrderStatus() async {
    print('Order status updated to: $selectedStatus');
  }

  @override
  Widget build(BuildContext context) {
    final order = widget.order;
    final buyerName = order['buyer']['name'];
    final totalPrice = order['total_price'];
    final orderItems = order['order_items'];

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const SellerOrdersPage()),
            );
          },
        ),
        title: const Text(
          'Order Info',
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: backgroundColor,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text('Buyer: $buyerName', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 8),
            Text('Total Price: $totalPrice EGP', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text('Payment Status: $selectedStatus', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 16),
            const Text('Order Items:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            ...orderItems.map<Widget>((item) {
              final product = item['product'];
              final productName = product['name'];
              final quantity = item['quantity'];
              final price = item['price'];

              // Get image
              String? imagePath;
              if (product['images'] != null && product['images'].isNotEmpty) {
                imagePath = product['images'][0]['image_path'];
              }
              String? fullImageUrl;
              if (imagePath != null) {
                fullImageUrl = 'https://olivedrab-llama-457480.hostingersite.com/$imagePath';
              }

              return Card(
                color: boxColor,
                margin: const EdgeInsets.symmetric(vertical: 8),
                elevation: 3,
                child: ListTile(
                  leading: fullImageUrl != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            fullImageUrl,
                            width: 60,
                            height: 60,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                                const Icon(Icons.broken_image, size: 40),
                          ),
                        )
                      : const Icon(Icons.image_not_supported, size: 40),
                  title: Text('$productName (x$quantity)', style: const TextStyle(fontWeight: FontWeight.w500)),
                  subtitle: Text('$price EGP', style: const TextStyle(color: Colors.grey)),
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }
}
