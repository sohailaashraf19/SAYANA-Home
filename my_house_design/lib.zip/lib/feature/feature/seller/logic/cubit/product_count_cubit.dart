

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:my_house_design/feature/feature/seller/data/data_sources/count_remote_data_source.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'product_count_state.dart';

class ProductCountCubit extends Cubit<ProductCountState> {
  final SummaryRemoteDataSource dataSource;

  ProductCountCubit(this.dataSource) : super(ProductCountInitial());

  Future<void> getProductCount() async {
    try {
      emit(ProductCountLoading());
      final prefs = await SharedPreferences.getInstance();
      final sellerIdStr = prefs.getString('sellerId') ?? '';
      final sellerId = int.tryParse(sellerIdStr) ?? 0;

      final data = await dataSource.fetchProductCount(sellerId);
      emit(ProductCountLoaded(data));
    } catch (e) {
      emit(ProductCountError(e.toString()));
    }
  }
}
