import 'package:dio/dio.dart';
import 'package:my_house_design/feature/feature/seller/data/models/product_count_model.dart';
import 'package:my_house_design/feature/feature/seller/data/models/revenue_model.dart';
import 'package:my_house_design/feature/feature/seller/data/models/sellerOrders_Model.dart';
import 'package:my_house_design/feature/feature/seller/data/models/uniquebuyers_model.dart';


class SummaryRemoteDataSource {
  final Dio dio;

  SummaryRemoteDataSource(this.dio);

  Future<UniqueBuyersModel> fetchUniqueBuyers(int sellerId) async {
    final response = await dio.get(
      'https://olivedrab-llama-457480.hostingersite.com/public/api/sellerunique-buyers/$sellerId',
    );

    return UniqueBuyersModel.fromJson(response.data);
  }
  Future<OrdersCountModel> fetchOrdersCount(int sellerId) async {
  final response = await dio.get('/sellerorders-count/$sellerId');
  return OrdersCountModel.fromJson(response.data);
}
Future<RevenueModel> fetchRevenue(int sellerId) async {
  final response = await dio.get('/sellerrevenue/$sellerId');
  return RevenueModel.fromJson(response.data);
}
Future<ProductCountModel> fetchProductCount(int sellerId) async {
  final response = await dio.get(
    'https://olivedrab-llama-457480.hostingersite.com/public/api/sellercount-products',
    queryParameters: {'saller_id': sellerId},
  );

  return ProductCountModel.fromJson(response.data);
}

}
