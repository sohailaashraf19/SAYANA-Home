

class ProductCountModel {
  final int productCount;

  ProductCountModel({required this.productCount});

  factory ProductCountModel.fromJson(Map<String, dynamic> json) {
    return ProductCountModel(
      productCount: json['product_count'] ?? 0,
    );
  }
}
