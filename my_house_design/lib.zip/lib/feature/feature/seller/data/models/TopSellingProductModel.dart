class TopSellingProduct {
  final int productId;
  final String name;
  final String totalSold;

  TopSellingProduct({
    required this.name,
    required this.totalSold,
        required this.productId,

  });
  factory TopSellingProduct.fromJson(Map<String, dynamic> json) {
    return TopSellingProduct(
      productId: json['product_id'],
      name: json['name'],
      totalSold: json['total_sold'],
    );
  }
}

