import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:my_house_design/core/core/helper/cache_helper.dart';
import 'package:my_house_design/feature/feature/buyer/presentation/screens/billing_summary_page.dart';
import 'package:my_house_design/presentation/widgets/color.dart'; // Assuming color constants like backgroundColor and boxColor

class BillingAddressPage extends StatefulWidget {
  const BillingAddressPage({super.key});

  @override
  _BillingAddressPageState createState() => _BillingAddressPageState();
}

class _BillingAddressPageState extends State<BillingAddressPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController streetController = TextEditingController();
  final TextEditingController streetNoController = TextEditingController();
  final TextEditingController floorNoController = TextEditingController();
  final TextEditingController buildingNoController = TextEditingController();

  bool isSubmitting = false;
  String errorMessage = '';
  String paymentMethod = 'cash';

  List<Map<String, dynamic>> cities = [
    {'id': 1, 'name': 'Cairo'},
    {'id': 2, 'name': 'Alexandria'},
    {'id': 3, 'name': 'Giza'},
    {'id': 4, 'name': 'Dakahlia'},
    {'id': 5, 'name': 'Red Sea'},
    {'id': 6, 'name': 'Beheira'},
    {'id': 7, 'name': 'Fayoum'},
    {'id': 8, 'name': 'Gharbia'},
    {'id': 9, 'name': 'Ismailia'},
    {'id': 10, 'name': 'Menofia'},
    {'id': 11, 'name': 'Minya'},
    {'id': 12, 'name': 'Qalyubia'},
    {'id': 13, 'name': 'New Valley'},
    {'id': 14, 'name': 'Suez'},
    {'id': 15, 'name': 'Aswan'},
    {'id': 16, 'name': 'Assiut'},
    {'id': 17, 'name': 'Beni Suef'},
    {'id': 18, 'name': 'Port Said'},
    {'id': 19, 'name': 'Dumyat'},   
    {'id': 19, 'name': 'Dumyat'},
    {'id': 20, 'name': 'Sharqia'},
    {'id': 21, 'name': 'South Sinai'},
    {'id': 22, 'name': 'Kafr El Sheikh'},
    {'id': 23, 'name': 'Matrouh'},
    {'id': 24, 'name': 'Luxor'},
    {'id': 25, 'name': 'Qena'},
    {'id': 26, 'name': 'North Sinai'},
    {'id': 27, 'name': 'Sohag'},


  ];

  int? selectedCityId;
  String? selectedCityName;

  XFile? transactionScreenshot;

  Future<void> submitAddress() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      isSubmitting = true;
    });

    final buyerId = await CacheHelper.getData(key: 'buyerId');

    if (buyerId == null) {
      setState(() {
        errorMessage = 'Buyer ID not found';
        isSubmitting = false;
      });
      return;
    }

    if (selectedCityName == null) {
      setState(() {
        errorMessage = 'Please select a city.';
        isSubmitting = false;
      });
      return;
    }

    if (paymentMethod == 'instapay' && transactionScreenshot == null) {
      setState(() {
        errorMessage = 'Please upload a transaction screenshot.';
        isSubmitting = false;
      });
      return;
    }

    final orderData = {
      'payment_method': paymentMethod,
      'street': streetController.text,
      'street_no': streetNoController.text,
      'floor_no': floorNoController.text,
      'building_no': buildingNoController.text,
      'offer': '0',
      'buyer_id': buyerId,
      'city_name': selectedCityName,
    };

    final url = Uri.parse('https://olivedrab-llama-457480.hostingersite.com/public/api/neworders');
    final headers = {'Content-Type': 'application/json'};

    try {
      final response = await http.post(url, headers: headers, body: jsonEncode(orderData));
      print('Status: ${response.statusCode}');
      print('Body  : ${response.body}');

      if (response.statusCode == 200) {
        final responseBody = jsonDecode(response.body);
        final orderId = responseBody['order']['id'];

        if (orderId != null) {
          await CacheHelper.saveData(key: 'orderId', value: orderId);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const BillingSummaryPage()),
          );

          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Address submitted successfully!')),
          );
        } else {
          setState(() {
            errorMessage = 'Order ID not found in the response.';
          });
        }
      } else {
        setState(() {
          errorMessage = 'Failed to submit address. Please try again.';
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = 'An error occurred: $e';
      });
    } finally {
      setState(() {
        isSubmitting = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        title: const Text('Billing Address', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color(0xFF003664),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Please provide your billing details',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),

                _buildInputField(Icons.location_on, 'Street', streetController),
                _buildInputField(Icons.location_on, 'Street Number', streetNoController),
                _buildInputField(Icons.location_on, 'Floor Number', floorNoController),
                _buildInputField(Icons.location_on, 'Building Number', buildingNoController),

                const SizedBox(height: 20),
                const Text('Choose Payment Method',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Radio<String>(
                      value: 'cash',
                      groupValue: paymentMethod,
                      onChanged: (value) => setState(() => paymentMethod = value!),
                    ),
                    const Text('Cash'),
                    Radio<String>(
                      value: 'instapay',
                      groupValue: paymentMethod,
                      onChanged: (value) => setState(() => paymentMethod = value!),
                    ),
                    const Text('InstaPay'),
                  ],
                ),

                const SizedBox(height: 20),
                const Text('Select Your City',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                DropdownButtonFormField<int>(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                  ),
                  value: selectedCityId,
                  items: cities.map((city) {
                    return DropdownMenuItem<int>(
                      value: city['id'],
                      child: Text(city['name']),
                    );
                  }).toList(),
                  onChanged: (value) {
                    final city = cities.firstWhere((c) => c['id'] == value);
                    setState(() {
                      selectedCityId = value;
                      selectedCityName = city['name'];
                    });
                  },
                  validator: (value) => value == null ? 'Please select a city' : null,
                ),

                if (paymentMethod == 'instapay') ...[
                  const SizedBox(height: 20),
                  const Text(
                    'Transfer to InstaPay Account: 010-XXXX-XXXX',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.upload),
                    label: Text(transactionScreenshot == null
                        ? 'Upload Transaction Screenshot'
                        : 'Change Screenshot'),
                    onPressed: () async {
                      final ImagePicker picker = ImagePicker();
                      final XFile? pickedImage = await picker.pickImage(source: ImageSource.gallery);
                      if (pickedImage != null) {
                        setState(() {
                          transactionScreenshot = pickedImage;
                        });
                      }
                    },
                  ),
                  if (transactionScreenshot != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Image.file(
                        File(transactionScreenshot!.path),
                        height: 150,
                      ),
                    ),
                ],

                const SizedBox(height: 20),
                if (errorMessage.isNotEmpty)
                  Text(errorMessage, style: const TextStyle(color: Colors.red)),

                const SizedBox(height: 20),
                isSubmitting
                    ? const Center(child: CircularProgressIndicator())
                    : ElevatedButton(
                        onPressed: submitAddress,
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          backgroundColor: const Color(0xFF003664),
                        ),
                        child: const Text('Submit', style: TextStyle(fontSize: 16, color: Colors.white)),
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputField(IconData icon, String label, TextEditingController controller) {
    return Card(
      color: boxColor,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFF003664), size: 22),
            const SizedBox(width: 10),
            Expanded(
              child: TextFormField(
                controller: controller,
                decoration: InputDecoration(labelText: label, border: InputBorder.none),
                validator: (value) =>
                    value == null || value.isEmpty ? '$label is required' : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
