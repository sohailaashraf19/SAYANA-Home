abstract class BuyerProfileState {}

class BuyerProfileInitial extends BuyerProfileState {}

class BuyerProfileLoading extends BuyerProfileState {}

class BuyerProfileSuccess extends BuyerProfileState {
  final Map<String, dynamic> profileData;

  BuyerProfileSuccess(this.profileData);
}

class BuyerProfileFailure extends BuyerProfileState {
  final String error;

  BuyerProfileFailure(this.error);
}
