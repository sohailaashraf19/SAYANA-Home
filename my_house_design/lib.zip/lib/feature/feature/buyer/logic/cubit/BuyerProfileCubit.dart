import 'dart:convert';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'buyer_profile_state.dart';

class BuyerProfileCubit extends Cubit<BuyerProfileState> {
  BuyerProfileCubit() : super(BuyerProfileInitial());

  final String _baseUrl = 'https://olivedrab-llama-457480.hostingersite.com/public/api';

  Future<void> fetchProfile() async {
    emit(BuyerProfileLoading());

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token');

      if (token == null) {
        emit(BuyerProfileFailure("No token found"));
        return;
      }

      final response = await http.get(
        Uri.parse('$_baseUrl/buyer/profile'),
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );

      if (response.statusCode == 200) {
  print('✅ API Response: ${response.body}');

  final rawData = jsonDecode(response.body);

  // ✅ Use rawData directly since there's no "data" key
  emit(BuyerProfileSuccess(rawData));
} else {
  emit(BuyerProfileFailure("Failed to fetch profile"));
}
 
    } catch (e) {
      emit(BuyerProfileFailure("Exception: $e"));
    }
  }
}
