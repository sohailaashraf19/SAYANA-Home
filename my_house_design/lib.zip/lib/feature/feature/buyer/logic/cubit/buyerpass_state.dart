abstract class BuyerForgetPasswordState {}

class BuyerForgetPasswordInitial extends BuyerForgetPasswordState {}

class BuyerForgetPasswordLoading extends BuyerForgetPasswordState {}

class BuyerForgetPasswordSuccess extends BuyerForgetPasswordState {
  final String message;

  BuyerForgetPasswordSuccess(this.message);
}

class BuyerForgetPasswordError extends BuyerForgetPasswordState {
  final String error;

  BuyerForgetPasswordError(this.error);
}
