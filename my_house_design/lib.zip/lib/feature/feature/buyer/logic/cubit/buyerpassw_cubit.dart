import 'package:dio/dio.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:my_house_design/feature/feature/buyer/data/data_sources/buyer_auth_data_source.dart';
import 'package:my_house_design/feature/feature/buyer/logic/cubit/buyerpass_state.dart';



class BuyerForgetPasswordCubit extends Cubit<BuyerForgetPasswordState> {
  final BuyerAuthRemoteDataSource remoteDataSource;

  BuyerForgetPasswordCubit(this.remoteDataSource) : super(BuyerForgetPasswordInitial());

  static BuyerForgetPasswordCubit get(context) => BlocProvider.of(context);

  Future<void> forgotPassword(String email) async {
    emit(BuyerForgetPasswordLoading());

    try {
      final Response message = await remoteDataSource.forgotPassword(email: email);
      emit(BuyerForgetPasswordSuccess(message as String));
    } catch (e) {
      emit(BuyerForgetPasswordError(e.toString()));
    }
  }
}
