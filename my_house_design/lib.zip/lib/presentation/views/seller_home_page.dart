import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:my_house_design/feature/feature/buyer/presentation/screens/botttomnavbar.dart';
import 'package:my_house_design/feature/feature/seller/data/data_sources/count_remote_data_source.dart';
import 'package:my_house_design/feature/feature/seller/data/models/HighestSpendingCustomerModel.dart';
import 'package:my_house_design/feature/feature/seller/data/models/TopSellingProductModel.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/HighestSpendingCustomerCubit%20.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/TopSellingProductsCubit.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/product_count_cubit.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/product_count_state.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/revenue_cubit.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/revenue_state.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/seller_orders_cubit.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/seller_orders_state.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/unique_buyers_cubit.dart';
import 'package:my_house_design/feature/feature/seller/logic/cubit/unique_buyers_state.dart';
import 'package:my_house_design/feature/feature/seller/presentation/screens/Settingss_Page.dart';
import 'package:my_house_design/feature/feature/seller/presentation/screens/products_screen.dart';
import 'package:my_house_design/feature/feature/seller/presentation/screens/seller_orders_page.dart';
import 'package:my_house_design/presentation/widgets/color.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Function to get seller ID from cache


class SellerHomePage extends StatefulWidget {
  const SellerHomePage({super.key});

  @override
  State<SellerHomePage> createState() => _SellerHomePageState();
}

class _SellerHomePageState extends State<SellerHomePage> {
  int currentIndex = 2;
  String userName = ''; // Store the brand name here

  @override
  void initState() {
    super.initState();
    _fetchUserName();
  }

  Future<void> _fetchUserName() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userName = prefs.getString('userName') ?? ''; 
    });
  }

@override
Widget build(BuildContext context) {
  return MultiBlocProvider(
    providers: [
      BlocProvider(
  create: (context) => UniqueBuyersCubit(SummaryRemoteDataSource( Dio()))..getUniqueBuyers(),
      ),
      BlocProvider(
  create: (context) => RevenueCubit(SummaryRemoteDataSource(Dio()))..getRevenue(),
  ),
    BlocProvider(
  create: (context) => OrdersCountCubit(SummaryRemoteDataSource(Dio()))..getOrdersCount(),
),
  BlocProvider(
  create: (context) => ProductCountCubit(SummaryRemoteDataSource(Dio()))..getProductCount(),
  child: SummaryCardsWidget(),
),

    
    ],
    child: Scaffold(
      backgroundColor: const Color.fromARGB(255, 255, 255, 255),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SellerTopBar(
                userName: userName,
                userImageUrl: 'assets/images/SYANA HOME.png',
              ),
              const SizedBox(height: 16),
              const SearchBarWidget(),
              const SizedBox(height: 16),
              const SummaryCardsWidget(), 
              const SizedBox(height: 24),
              const TrendingProductsWidget(),
              const SizedBox(height: 24),
              const HighestSpendingCustomersWidget(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        onTap: (index) {
          if (index != currentIndex) {
            setState(() {
              currentIndex = index;
            });

            Widget destination;
            switch (index) {
              case 0:
                destination = const ProductScreen();
                break;
              case 1:
                destination = const SellerOrdersPage();
                break;
              case 2:
                destination = const SellerHomePage();
                break;
              case 3:
                destination = const SettingssPage();
                break;
              default:
                destination = const SellerHomePage();
            }

            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => destination),
            );
          }
        },
        items: [
          navitem(icon: Icons.inventory_2_outlined, label: "Products", index: 0, currentIndex: currentIndex),
          navitem(icon: Icons.shopping_cart_outlined, label: "Orders", index: 1, currentIndex: currentIndex),
          navitem(icon: Icons.home, label: "Home", index: 2, currentIndex: currentIndex),
          navitem(icon: Icons.settings, label: "Settings", index: 3, currentIndex: currentIndex),
        ],
        selectedItemColor: Colors.white,
        selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
      ),
    ),
  );
}
}

class SellerTopBar extends StatelessWidget {
  final String userName;
  final String userImageUrl;

  const SellerTopBar({
    super.key,
    required this.userName,
    required this.userImageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CircleAvatar(
          radius: 24,
          backgroundImage: AssetImage(userImageUrl),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Thursday, Feb 5, 1985',
                style: TextStyle(fontSize: 12, color: Color(0xFF003664)),
              ),
              Text(
                'Hello $userName !',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF003664),
                  fontFamily: 'Cursive',
                ),
              ),
            ],
          ),
        ),
        const Icon(Icons.notifications_none, color: Color(0xFF003664)),
      ],
    );
  }
}

class SearchBarWidget extends StatefulWidget {
  const SearchBarWidget({super.key});

  @override
  State<SearchBarWidget> createState() => _SearchBarWidgetState();
}

class _SearchBarWidgetState extends State<SearchBarWidget> {
  final TextEditingController _controller = TextEditingController();
  final List<String> _allSuggestions = [
    "Nancy Chair",
    "Coffee Table",
    "LG Refrigerator",
    "Dining Table",
    "Office Desk",
    "Modern Sofa",
    "Customer: Omar Ashraf",
    "Order: #10234"
  ];

  List<String> _filteredSuggestions = [];

  void _onSearchChanged(String query) {
    setState(() {
      _filteredSuggestions = _allSuggestions
          .where((item) => item.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextField(
          controller: _controller,
          onChanged: _onSearchChanged,
          decoration: InputDecoration(
            hintText: 'Search order, product, customer',
            hintStyle: const TextStyle(color: Color(0xFF003664)),
            prefixIcon: const Icon(Icons.search, color: Color(0xFF003664)),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(25),
              borderSide: const BorderSide(color: Color(0xFF003664)),
            ),
            filled: true,
            fillColor: boxColor,
          ),
          style: const TextStyle(color: Color(0xFF003664)),
        ),
        const SizedBox(height: 10),
        ..._filteredSuggestions.map((suggestion) => ListTile(
              title: Text(suggestion, style: const TextStyle(color: Color(0xFF003664))),
              onTap: () {
                _controller.text = suggestion;
                setState(() {
                  _filteredSuggestions.clear();
                });
              },
            )),
      ],
    );
  }
}
class SummaryCardsWidget extends StatelessWidget {
  const SummaryCardsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        BlocBuilder<RevenueCubit, RevenueState>(
          builder: (context, revenueState) {
            if (revenueState is RevenueLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (revenueState is RevenueLoaded) {
              final revenueData = revenueState.data;

              return BlocBuilder<OrdersCountCubit, OrdersCountState>(
                builder: (context, ordersState) {
                  final totalOrders = (ordersState is OrdersCountLoaded)
                      ? ordersState.data.totalOrdersParticipatedIn.toString()
                      : '...';

                  return BlocBuilder<UniqueBuyersCubit, UniqueBuyersState>(
                    builder: (context, buyersState) {
                      final totalCustomers = (buyersState is UniqueBuyersLoaded)
                          ? buyersState.data.uniqueBuyersCount.toString()
                          : '...';

                      return BlocBuilder<ProductCountCubit, ProductCountState>(
                        builder: (context, productState) {
                          if (productState is ProductCountLoaded) {
                            final productCount = productState.data.productCount;

                            return GridView.count(
                              crossAxisCount: 2,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              crossAxisSpacing: 12,
                              mainAxisSpacing: 12,
                              children: [
                                _buildCard('Revenue', 'EGP ${revenueData.netProfit95Percent}', 'assets/images/Ney.jpg'),
                                _buildCard('Total Sales', 'EGP ${revenueData.totalSalesBeforeFees}', 'assets/images/vini.jpeg'),
                                _buildCard('Total Orders', totalOrders, 'assets/images/Rony.jpeg'),
                                _buildCard('Total Customers', totalCustomers, 'assets/images/rodry.jpeg'),
                                _buildCard('Products', '$productCount', 'assets/images/prod.jpg'),
                                // 
                              ],
                            );
                          } else if (productState is ProductCountError) {
                            return Center(child: Text('Error: ${productState.message}'));
                          } else {
                            return const Center(child: CircularProgressIndicator());
                          }
                        },
                      );
                    },
                  );
                },
              );
            } else if (revenueState is RevenueError) {
              return Center(child: Text('Revenue Error: ${revenueState.message}'));
            } else {
              return const SizedBox.shrink();
            }
          },
        ),
      ],
    );
  }

  Widget _buildCard(String title, String value, String imagePath) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            backgroundImage: AssetImage(imagePath),
            radius: 24,
          ),
          const SizedBox(height: 12),
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(fontSize: 14, color: Colors.black54),
          ),
        ],
      ),
    );
  }
}




class TrendingProductsWidget extends StatelessWidget {

  const TrendingProductsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => TopSellingProductCubit()..fetchTopSellingProducts(),
      child: BlocBuilder<TopSellingProductCubit, List<TopSellingProduct>>(
        builder: (context, products) {
          if (products.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Trending Products',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF003664))),
              const SizedBox(height: 12),
              SizedBox(
                height: 160,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: products.map((product) {
                    return Container(
                      width: 140,
                      margin: const EdgeInsets.only(right: 12),
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: boxColor,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Expanded(child: Icon(Icons.chair_alt_rounded, size: 50, color: Color(0xFF003664))),
                          const SizedBox(height: 8),
                          Text(product.name,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF003664))),
                          Text("${product.totalSold} Sold",
                              style: const TextStyle(fontSize: 12, color: Color(0xFF003664))),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}


class HighestSpendingCustomersWidget extends StatelessWidget {
  const HighestSpendingCustomersWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => HighestSpendingCustomerCubit()..fetchHighestSpendingCustomers(),
      child: BlocBuilder<HighestSpendingCustomerCubit, List<HighestSpendingCustomer>>(
        builder: (context, customers) {
          if (customers.isEmpty) {
            return Center(child: CircularProgressIndicator());
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Highest Spending Customers',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF003664)),
              ),
              const SizedBox(height: 12),
              Column(
                children: customers.map((customer) {
                  return ListTile(
                    title: Text(customer.name, style: const TextStyle(color: Color(0xFF003664))),
                    subtitle: Text(
                      "Total Orders: ${customer.totalOrders}",
                      style: const TextStyle(color: Color(0xFF003664)),
                    ),
                    trailing: const Icon(Icons.more_vert, color: Color(0xFF003664)),
                  );
                }).toList(),
              ),
            ],
          );
        },
      ),
    );
  }
}
