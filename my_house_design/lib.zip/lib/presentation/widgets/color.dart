import 'package:flutter/material.dart';


const Color primaryColor = Color(0xFF003664); // for checkbox or selection
const Color backgroundColor = Color(0xFFFBFBFB); // for background      
const Color smalltextColor = Color(0xFF46656F); // for small text
const Color boxColor = Color(0xFFEFF4F7); // لون اي box 
const Color redColor = Colors.red; // red color for cart icon
const Color boldtextColor =Colors.black;
const Color iconColor = Colors.black;
const Color selectediconColor = Color(0xFF2c3e50) ;