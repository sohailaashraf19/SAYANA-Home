class ApiService {
  static const apiKey = 'AIzaSyCkN8Pm5u8loaCq5tmRhBumS6lQtzYaRNY';
}